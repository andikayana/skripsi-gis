<footer style="background-color: #0D47A1" class="page-footer">
          <div class="footer-copyright">
            <div class="container">
              © 2016 Copyright 
              <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
</footer>
<!--  Scripts-->
    <script type="text/javascript">
      $(document).ready(function() {
      $('select').material_select();
  });
    </script>